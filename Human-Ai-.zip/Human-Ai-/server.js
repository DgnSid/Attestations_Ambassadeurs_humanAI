const express = require('express');
const path = require('path');
const app = express();
const port = 3001; // Vous pouvez utiliser un autre port si nécessaire

// Servir les fichiers statiques du répertoire Generate_Attestation
app.use(express.static(path.join(__dirname, 'Generate_Attestation')));

// Route principale pour le répertoire Generate_Attestation
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'Generate_Attestation', 'index.html'));
});

// Démarrer le serveur
app.listen(port, () => {
  console.log(`Serveur frontend en cours d'exécution sur http://localhost:${port}`);
});
