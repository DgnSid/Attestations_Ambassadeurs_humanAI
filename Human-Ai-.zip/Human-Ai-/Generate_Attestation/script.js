function telecharge() {
    var certificat = document.getElementById('attestation');

    var opt = {
        margin: [0, 0, 0, 0],
        filename: `Attestation_Ambassadeur_${localStorage.getItem("nom")}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    html2pdf().from(certificat).set(opt).save().then(() => {
        Swal.fire({
            title: "Téléchargement Réussi !",
            text: "Cliquez sur le bouton!",
            icon: "success",
        });
    }).catch(error => {
        console.error('Erreur lors du téléchargement du PDF :', error);
        Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "Une erreur s'est produite lors du téléchargement du PDF.",
        });
    });
}

function capitalize(prenom) {
    return prenom.split(" ").map(part => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase()).join(" ");
}

document.addEventListener("DOMContentLoaded", function() {
    const start = document.querySelector(".start");
    if (start) {
        start.addEventListener("click", () => {
            console.log("Bouton démarrer cliqué");
            const body = document.querySelector("body");
            body.innerHTML = `
                <div class="formdiv" id="form">
                    <div class="flex justify-center items-center max-w-[440px] text-white my-2 bg-green-400 h-auto p-2 m-2">
                        <div class="pl-4 font-bold">
                            Veuillez renseigner votre adresse e-mail utilisée lors de l'inscription en tant qu'ambassadeur.
                        </div>
                    </div>
                    <form class="w-full bg-white shadow-md h-auto max-w-[440px] p-3 mx-2">
                        <div class="mx-auto">
                            <div>
                                <input type="email" placeholder="Votre E-mail" class="input form_email" required>
                            </div>
                            <div class="relative">
                                <input type="button" value="SOUMETTRE" class="mt-3 bg-slate-900 text-white text-center relative p-3 block w-full hover:font-bold" onclick="afficherPDF()">
                                <div id="spin"></div>
                            </div>
                        </div>
                    </form>
                </div>
            `;
        });
    } else {
        console.error("Bouton démarrer non trouvé");
    }
});

function afficherPDF() {
    const form_email = document.querySelector(".form_email").value;

    if (form_email) {
        fetch('http://localhost:3000/verifier-utilisateur', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email: form_email }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.utilisateurTrouve) {
                const { nom, prenom, dateAdhesion } = data;
                rowNumber = data.rowNumber; // Stocker le numéro de la ligne de l'utilisateur
                document.getElementById("spin").classList.add('spin');

                const body = document.querySelector("body");
                body.innerHTML = `
                    <div class="w-full h-screen flex flex-col justify-center items-center bg-white">
                        <div class="">
                            <button onclick="telecharge()" class="text-white bg-slate-900 mt-2 p-4 hover:font-bold">DOWNLOAD</button>
                        </div>
                        <div class="w-full h-screen flex flex-col justify-center bg-white">
                            <div class="attestation w-[800px] h-[500px] mx-auto relative overflow-hidden" id="attestation">
                                <img src="./assets/background.png" alt="" class="absolute top-0 left-0 right-0 bottom-0" crossOrigin="anonymous">
                                <img src="./assets/bordure.png" alt="" class="absolute top-0 left-0 right-0 bottom-0 w-[800px] h-[500px]" crossOrigin="anonymous">
                                <div class="w-full absolute top-4">
                                    <div class="entete flex justify-evenly items-center px-3 mx-4">
                                        <img src="./assets/logo.png" alt="" class="w-32 h-32 object-cover mt-6 -ml-[70px]" crossOrigin="anonymous">
                                        <h1 class="text-4xl font-bold font-cinzel mt-6 tracking-wider">ATTESTATION <br class="mt-4"> <span class="text-3xl text-center">D'AMBASSADEUR</span></h1>
                                        <img src="./assets/logo.png" alt="" class="w-32 h-32 object-cover mt-5 -mr-[70px]" crossOrigin="anonymous">
                                    </div>
                                    <div class="contenu flex flex-col justify-center items-center">
                                        <p class="text-xl mt-2">Décernée à :</p>
                                        <h2 class="text-2xl font-bold mt-3 font-glacial">${capitalize(prenom)} ${nom.toUpperCase()}</h2>
                                        <hr class="h-5 w-[200px] border-slate-600 mt-2">
                                        <p class="text-xl">Est Ambassadeur de <span class="text-human font-bold">Human AI</span></p>
                                        <p class="text-xl">Depuis le <span>${dateAdhesion}</span></p>
                                    </div>
                                    <div class="flex justify-center -mt-2">
                                        <img src="./assets/bagde.png" alt="" class="w-32 h-40 object-cover" crossOrigin="anonymous">
                                    </div>
                                    <div class="relative -top-44">
                                        <img src="./assets/Cachet_Human_AI.png" alt="" class="relative w-60 h-48 float-end mr-[134px] object-cover" crossOrigin="anonymous">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                // Réattacher le script au bouton de téléchargement
                const downloadButton = document.querySelector("button[onclick='telecharge()']");
                if (downloadButton) {
                    downloadButton.onclick = telecharge;
                }
            } else {
                document.getElementById("spin").classList.add('spin');
                setTimeout(() => {
                    document.getElementById("spin").classList.remove('spin');
                }, 2000);
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "Vous n'êtes pas ambassadeur de Human AI",
                });
            }
        })
        .catch(error => {
            document.getElementById("spin").classList.add('spin');
            setTimeout(() => {
                document.getElementById("spin").classList.remove('spin');
            }, 2000);
            console.error('Erreur lors de la requête vers le backend :', error);
            Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Une erreur s'est produite lors de la vérification de l'utilisateur.",
            });
        });
    } else {
        Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "Veuillez remplir toutes les informations",
        });
    }
}
