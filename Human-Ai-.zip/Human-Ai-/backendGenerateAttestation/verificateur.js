const ExcelJS = require("exceljs");

async function verifierUtilisateur(email) {
    const workbook = new ExcelJS.Workbook();

    try {
        console.log("Début de la lecture du fichier Excel.");
        await workbook.xlsx.readFile("backendGenerateAttestation/ambassadeurs.xlsx");
        console.log("Fichier Excel lu avec succès.");

        const worksheet = workbook.getWorksheet(1);
        console.log("Worksheet obtenu avec succès.");

        let utilisateurTrouve = false;
        let nom = null;
        let prenom = null;
        let dateAdhesion = null;
        let userRowNumber = null;

        worksheet.eachRow((row, rowNumber) => {
            let emailFichier = row.getCell(14).value;
            let nomFichier = row.getCell(2).value;
            let prenomFichier = row.getCell(3).value;

            console.log(`Lecture de la ligne ${rowNumber}: email: ${emailFichier}, nom: ${nomFichier}, prenom: ${prenomFichier}`);
            console.log(`Type de emailFichier: ${typeof emailFichier}`);

            // Afficher la structure de l'objet si ce n'est pas une chaîne de caractères
            if (typeof emailFichier === 'object') {
                console.log('Structure de l\'objet emailFichier:', JSON.stringify(emailFichier));
                // Extraire l'email de l'objet si possible
                emailFichier = emailFichier.text || emailFichier.hyperlink || emailFichier.richText || '';
            }

            // Convertir les valeurs en chaînes de caractères si nécessaire
            if (emailFichier && typeof emailFichier !== 'string') {
                emailFichier = emailFichier.toString();
            }
            if (nomFichier && typeof nomFichier !== 'string') {
                nomFichier = nomFichier.toString();
            }
            if (prenomFichier && typeof prenomFichier !== 'string') {
                prenomFichier = prenomFichier.toString();
            }

            const emailSaisi = email.toLowerCase();
            console.log(`Comparaison des emails: ${emailFichier.toLowerCase()} === ${emailSaisi}`);

            // Vérifier si la cellule contient une valeur et si c'est une chaîne de caractères
            if (emailFichier && typeof emailFichier === 'string' && emailFichier.toLowerCase() === emailSaisi) {
                utilisateurTrouve = true;
                nom = nomFichier;
                prenom = prenomFichier;
                const dateCellValue = row.getCell(1).value;

                console.log(`Utilisateur trouvé à la ligne ${rowNumber}: Nom: ${nom}, Prénom: ${prenom}, Date: ${dateCellValue}`);

                if (typeof dateCellValue === 'string') {
                    const isoDate = new Date(dateCellValue); // Crée un objet Date à partir du format ISO
                    dateAdhesion = isoDate.toLocaleDateString("fr-FR", {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                    });
                } else if (dateCellValue instanceof Date) {
                    dateAdhesion = dateCellValue.toLocaleDateString("fr-FR", {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                    });
                } else {
                    dateAdhesion = "Date invalide";
                }

                userRowNumber = rowNumber;
                return false; // Arrêter la boucle
            }
        });

        console.log(`Utilisateur trouvé: ${utilisateurTrouve}, Nom: ${nom}, Prénom: ${prenom}`);
        return { utilisateurTrouve, nom, prenom, dateAdhesion, rowNumber: userRowNumber };
    } catch (error) {
        console.error("Erreur lors de la vérification de l'utilisateur :", error);
        throw error;
    }
}

module.exports = { verifierUtilisateur };
