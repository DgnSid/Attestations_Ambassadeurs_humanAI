const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { verifierUtilisateur } = require("./verificateur");
const app = express();
const port = 3000;

app.use(express.json());
app.use(cors());

app.get("/", (req, res) => {
    res.send("Amos");
});

app.post("/verifier-utilisateur", async (req, res) => {
    const { email } = req.body;

    try {
        console.log(`Vérification de l'utilisateur avec l'e-mail : ${email}`);
        const { utilisateurTrouve, nom, prenom, dateAdhesion, rowNumber } = await verifierUtilisateur(email);

        if (utilisateurTrouve) {
            res.json({ utilisateurTrouve: true, nom, prenom, dateAdhesion, rowNumber });
        } else {
            res.json({ utilisateurTrouve: false });
        }
    } catch (error) {
        console.error("Erreur lors de la vérification de l'utilisateur :", error);
        res.status(500).json({ erreur: "Une erreur s'est produite lors de la vérification de l'utilisateur." });
    }
});

app.listen(port, () => {
    console.log(`Serveur Express en cours d'exécution sur le port ${port}`);
});
